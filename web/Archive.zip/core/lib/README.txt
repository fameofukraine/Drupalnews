The core/lib directory is for classes provided by Drupal Core that are original
to Drupal. All Drupal-originated code must follow the PSR-4 naming convention
for classes and namespaces as documented here:

https://github.com/php-fig/fig-standards/blob/master/accepted/PSR-4-autoloader.md

The vendor namespace for Drupal-originated code is "Drupal".
